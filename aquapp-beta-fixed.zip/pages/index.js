import React from "react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Gauge } from "lucide-react";
import dynamic from 'next/dynamic';

const BIMViewer = dynamic(() => import('../components/BIMViewer'), { ssr: false });

export default function Dashboard() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-[#001F3F] to-[#001733] text-white p-6">
      <header className="flex items-center justify-between mb-10">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white text-[#001F3F] font-bold text-xl flex items-center justify-center rounded-full">
            <div className="text-sm leading-tight">🔺</div>
          </div>
          <h1 className="text-2xl font-bold tracking-wide">QUAPP</h1>
        </div>
        <Button variant="outline">Cerrar sesión</Button>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <Card className="bg-[#002A50] border-none">
          <CardContent className="p-4">
            <h2 className="text-lg font-semibold mb-2">Activos Críticos</h2>
            <p>Grilletes (12)</p>
            <p>Cadenas (8)</p>
            <p>Boyas (6)</p>
          </CardContent>
        </Card>

        <Card className="bg-[#002A50] border-none">
          <CardContent className="p-4">
            <h2 className="text-lg font-semibold mb-2">Alertas de Mantenimiento</h2>
            <p className="text-green-400">Verde: 5</p>
            <p className="text-yellow-400">Amarillo: 3</p>
            <p className="text-red-500">Rojo: 2</p>
          </CardContent>
        </Card>

        <Card className="bg-[#002A50] border-none">
          <CardContent className="p-4">
            <h2 className="text-lg font-semibold mb-2">Costos Mensuales</h2>
            <p>Total: $3.200.000 CLP</p>
            <p>Repuestos: $1.200.000 CLP</p>
            <p>Mano de obra: $2.000.000 CLP</p>
          </CardContent>
        </Card>
      </section>

      <section className="bg-[#001F3F] p-6 rounded-xl mb-10">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <Gauge className="w-5 h-5" /> Indicador de Salud Operacional
        </h2>
        <div className="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
          <div className="bg-green-500 h-full w-[70%]"></div>
        </div>
        <p className="text-sm text-gray-300 mt-2">70% condiciones operativas óptimas</p>
      </section>

      <section className="bg-[#001A2F] p-6 rounded-xl mb-10">
        <h2 className="text-xl font-semibold mb-4">Visualizador BIM 3D</h2>
        <div className="h-[500px] rounded-xl border border-gray-700">
          <BIMViewer />
        </div>
      </section>

      <section className="bg-[#001733] p-6 rounded-xl">
        <h2 className="text-xl font-semibold mb-4">Generar Reporte de Salida</h2>
        <Button className="bg-white text-[#001F3F] font-semibold">Descargar PDF</Button>
      </section>
    </main>
  );
}
