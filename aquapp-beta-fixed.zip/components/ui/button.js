export function Button({ children, className, variant }) {
  return <button className={`px-4 py-2 rounded ${variant === 'outline' ? 'border border-white text-white' : 'bg-white text-black'} ${className}`}>{children}</button>;
}