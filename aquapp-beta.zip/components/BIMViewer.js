export default function BIMViewer() {
  return (
    <div className='flex items-center justify-center h-full text-gray-300'>
      [Visualizador BIM en construcción...]
    </div>
  );
}