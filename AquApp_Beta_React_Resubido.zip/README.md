# AquApp Beta

Plataforma beta funcional construida con React y Tailwind.

## Cómo desplegar

1. Abre [https://vercel.com](https://vercel.com)
2. Crea un nuevo proyecto
3. Sube esta carpeta o conecta tu repositorio
4. ¡Listo!